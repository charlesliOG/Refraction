#ifndef MODEL_H
#define MODEL_H


class Model
{


public:
    Model();



};

#endif // MODEL_H
